
import streamlit as st
import requests
import pandas as pd
from PIL import Image
import tempfile

# 标准答案
standard_answers = {
    "4-1": "to help",
    "4-2": "buying",
    "4-3": "to ask",
    "4-4": "being",
    "4-5": "showing",
    "4-6": "talking",
    "5-1": "to show",
    "5-2": "to indicate",
    "5-3": "going",
    "5-4": "to spend",
    "5-5": "to see",
    "5-6": "rising"
}

# 使用 OCR.space 云 API 提取文字
def extract_text_cloud(image_bytes):
    api_key = 'helloworld'  # 免费测试 Key，推荐换成自己的
    url = 'https://api.ocr.space/parse/image'
    response = requests.post(url, files={'filename': image_bytes}, data={
        'apikey': api_key,
        'language': 'eng',
        'isOverlayRequired': False
    })
    result = response.json()
    if result.get("IsErroredOnProcessing"):
        return "OCR 识别失败：" + result.get("ErrorMessage", ["未知错误"])[0]
    return result['ParsedResults'][0]['ParsedText']

st.title("英语作业自动批改系统（兼容 Streamlit 云端）📘")
uploaded_file = st.file_uploader("请上传学生作业（图片或PDF）", type=["jpg", "jpeg", "png"])

if uploaded_file:
    st.success("文件上传成功 ✅")
    image = Image.open(uploaded_file)

    # 显示上传的图片
    st.image(image, caption="上传的作业图片", use_column_width=True)

    with st.spinner("正在识别文字..."):
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp:
            image.save(tmp.name)
            with open(tmp.name, 'rb') as f:
                image_bytes = f.read()
            ocr_text = extract_text_cloud(image_bytes)

    # 显示提取文本
    with st.expander("查看识别文字内容"):
        st.text(ocr_text)

    # 自动批改
    st.subheader("批改结果")
    student_text = ocr_text.lower()
    results = []
    for key, correct_answer in standard_answers.items():
        if correct_answer.lower() in student_text:
            results.append((key, correct_answer, correct_answer, "✔"))
        else:
            results.append((key, "未知", correct_answer, "✘"))

    df = pd.DataFrame(results, columns=["题号", "学生答案", "正确答案", "判定"])
    st.table(df)
